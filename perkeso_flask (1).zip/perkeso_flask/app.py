"""
Aplikasi Web Flask — Jana Surat PERKESO (OB & OT)
Keperluan: pip install flask python-docx
"""

from __future__ import annotations

import io
import os
import re
from contextlib import suppress
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable, Optional

from flask import Flask, render_template, request, send_file, jsonify

try:
    from docx import Document
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
except ImportError:
    raise SystemExit("Sila pasang python-docx:\n  pip install python-docx")

app = Flask(__name__)

@app.context_processor
def inject_now():
    return {"now": datetime.now()}

# =============================================================================
# 1. KONFIGURASI BERSAMA
# =============================================================================

BULAN_MS: dict[int, str] = {
    1: "Januari",   2: "Februari",  3: "Mac",      4: "April",
    5: "Mei",       6: "Jun",       7: "Julai",    8: "Ogos",
    9: "September", 10: "Oktober",  11: "November", 12: "Disember",
}

SENARAI_FAEDAH: list[str] = [
    "Faedah Hilangupaya Sementara",
    "Faedah Orang Tanggunggan",
    "Pencen Ilat",
    "Bayaran Faedah Pencen Penakat",
    "Bayaran Faedah Pengurusan Mayat",
    "Elaun Layanan Sentiasa",
    "Penyakit Khidmat",
    "Bayaran Ganti Belanja",
    "Bantuan Ilat",
]

FOLDER_OUTPUT = "output"


@dataclass
class TakrifMedan:
    label: str
    kunci: str
    jenis: str = "entry"
    wajib: bool = True


# =============================================================================
# 2. KONFIGURASI PER-KES (OB & OT)
# =============================================================================

@dataclass
class KonfigKes:
    nama_kes:         str
    tajuk_tetingkap:  str
    sub_header:       str
    nama_template:    str
    senarai_medan:    list[TakrifMedan]
    bina_ph_map:      Callable[[dict, str, str, str], dict]
    warna_butang:     str = "#0066cc"


# ── Kes OB ────────────────────────────────────────────────────────────────────

SENARAI_MEDAN_OB: list[TakrifMedan] = [
    TakrifMedan("No. Rujukan",              "no_rujukan"),
    TakrifMedan("Tarikh",                   "tarikh"),
    TakrifMedan("Nama Waris",               "nama_waris"),
    TakrifMedan("No. KP Simati",            "no_kp"),
    TakrifMedan("Alamat",                   "alamat",        jenis="textarea"),
    TakrifMedan("Jenis Faedah 1",           "jenis_faedah",  jenis="combo"),
    TakrifMedan("Jenis Faedah 2 (pilihan)", "jenis_faedah2", jenis="combo_opt", wajib=False),
    TakrifMedan("Jumlah Wang (RM)",         "jumlah",        jenis="jumlah"),
]


def _ph_map_ob(data: dict, jumlah_angka: str, jumlah_teks: str, faedah_display: str) -> dict:
    return {
        "{{NamaWaris}}":   data["nama_waris"],
        "{{NoKP}}":        data["no_kp"],
        "{{Alamat}}":      data["alamat"],
        "{{Tarikh}}":      data["tarikh"],
        "{{NoRujukan}}":   data["no_rujukan"],
        "{{JenisFaedah}}": faedah_display,
        "{{JumlahAngka}}": jumlah_angka,
        "{{JumlahTeks}}":  jumlah_teks,
        "{{BlokRinggit}}": f"(Ringgit Malaysia: {jumlah_teks})",
    }


KES_OB = KonfigKes(
    nama_kes        = "OB",
    tajuk_tetingkap = "Jana Surat Tuntutan PERKESO — Kes OB",
    sub_header      = "Sistem Jana Surat Bayaran Faedah Sebagai Harta Pusaka",
    nama_template   = "Template OB.docx",
    senarai_medan   = SENARAI_MEDAN_OB,
    bina_ph_map     = _ph_map_ob,
    warna_butang    = "#0066cc",
)


# ── Kes OT ────────────────────────────────────────────────────────────────────

SENARAI_MEDAN_OT: list[TakrifMedan] = [
    TakrifMedan("No. Rujukan",                  "no_rujukan"),
    TakrifMedan("Tarikh",                       "tarikh"),
    TakrifMedan("Alamat",                       "alamat",        jenis="textarea"),
    TakrifMedan("Nama OB (Orang Berinsurans)",  "nama_ob"),
    TakrifMedan("No. KP OB",                    "no_kp_ob"),
    TakrifMedan("Nama Penerima Faedah",         "nama_waris"),
    TakrifMedan("No. KP Waris / OT",            "no_kp_ot"),
    TakrifMedan("Jenis Faedah 1",               "jenis_faedah",  jenis="combo"),
    TakrifMedan("Jenis Faedah 2 (pilihan)",     "jenis_faedah2", jenis="combo_opt", wajib=False),
    TakrifMedan("Jumlah Wang (RM)",             "jumlah",        jenis="jumlah"),
]


def _ph_map_ot(data: dict, jumlah_angka: str, jumlah_teks: str, faedah_display: str) -> dict:
    return {
        "{{NamaWaris}}":   data["nama_waris"],
        "{{Alamat}}":      data["alamat"],
        "{{Tarikh}}":      data["tarikh"],
        "{{NoRujukan}}":   data["no_rujukan"],
        "{{NamaOB}}":      data["nama_ob"],
        "{{NoKPOB}}":      data["no_kp_ob"],
        "{{NamaOT}}":      data["nama_waris"],
        "{{NoKPOT}}":      data["no_kp_ot"],
        "{{JenisFaedah}}": faedah_display,
        "{{JumlahAngka}}": jumlah_angka,
        "{{BlokRinggit}}": f"(Ringgit Malaysia: {jumlah_teks})",
    }


KES_OT = KonfigKes(
    nama_kes        = "OT",
    tajuk_tetingkap = "Jana Surat Tuntutan PERKESO — Kes OT",
    sub_header      = "Jana Surat — Kes Orang Tanggungan (OT) Meninggal Dunia",
    nama_template   = "Template OT.docx",
    senarai_medan   = SENARAI_MEDAN_OT,
    bina_ph_map     = _ph_map_ot,
    warna_butang    = "#1a7a5e",
)

SEMUA_KES: dict[str, KonfigKes] = {"OB": KES_OB, "OT": KES_OT}


# =============================================================================
# 3. UTILITI WANG
# =============================================================================

_SATU_HINGGA_19 = [
    "", "Satu", "Dua", "Tiga", "Empat", "Lima",
    "Enam", "Tujuh", "Lapan", "Sembilan", "Sepuluh",
    "Sebelas", "Dua Belas", "Tiga Belas", "Empat Belas", "Lima Belas",
    "Enam Belas", "Tujuh Belas", "Lapan Belas", "Sembilan Belas",
]
_PULUHAN = [
    "", "", "Dua Puluh", "Tiga Puluh", "Empat Puluh", "Lima Puluh",
    "Enam Puluh", "Tujuh Puluh", "Lapan Puluh", "Sembilan Puluh",
]


def _bawah_1000(num: int) -> str:
    if num == 0:  return ""
    if num < 20:  return _SATU_HINGGA_19[num]
    if num < 100:
        baki = num % 10
        return _PULUHAN[num // 10] + (f" {_SATU_HINGGA_19[baki]}" if baki else "")
    ratus, baki = divmod(num, 100)
    prefix = "Seratus" if ratus == 1 else f"{_SATU_HINGGA_19[ratus]} Ratus"
    return prefix + (f" {_bawah_1000(baki)}" if baki else "")


def _eja_nombor(n: int) -> str:
    if n == 0:
        return "Sifar"
    peringkat = [
        (1_000_000, "Sejuta",  lambda x: f"{_bawah_1000(x)} Juta"),
        (1_000,     "Seribu",  lambda x: f"{_bawah_1000(x)} Ribu"),
    ]
    bahagian: list[str] = []
    for pembahagi, tunggal, jamak_fn in peringkat:
        if n >= pembahagi:
            kuantiti, n = divmod(n, pembahagi)
            bahagian.append(tunggal if kuantiti == 1 else jamak_fn(kuantiti))
    if n > 0:
        bahagian.append(_bawah_1000(n))
    return " ".join(bahagian)


def wang_ke_teks(jumlah_str: str) -> str:
    with suppress(ValueError):
        jumlah  = float(jumlah_str.replace(",", ""))
        ringgit = int(jumlah)
        sen     = round((jumlah - ringgit) * 100)
        eja_rm  = _eja_nombor(ringgit)
        if sen == 0:
            return f"Ringgit Malaysia: {eja_rm} Sahaja"
        return f"Ringgit Malaysia: {eja_rm} dan SEN {_eja_nombor(sen)} Sahaja"
    return ""


def format_jumlah_angka(jumlah_str: str) -> str:
    with suppress(ValueError):
        return f"RM{float(jumlah_str.replace(',', '')):,.2f}"
    return jumlah_str


# =============================================================================
# 4. PEMPROSES DOC
# =============================================================================

class PemprosesDoc:

    def __init__(self, senarai_faedah: list[str]) -> None:
        self.senarai_faedah = senarai_faedah
        self._pattern_faedah = re.compile(
            "(" + "|".join(re.escape(f) for f in senarai_faedah) + ")"
        )

    @staticmethod
    def _tambah_bold(rPr: OxmlElement) -> None:
        if rPr.find(qn("w:b")) is None:
            rPr.insert(0, OxmlElement("w:b"))
        if rPr.find(qn("w:bCs")) is None:
            rPr.insert(1, OxmlElement("w:bCs"))

    @staticmethod
    def _buang_bold(rPr: OxmlElement) -> None:
        for tag in ("w:b", "w:bCs"):
            for el in rPr.findall(qn(tag)):
                rPr.remove(el)

    @staticmethod
    def _dapatkan_rPr(paragraph) -> Optional[OxmlElement]:
        for run in paragraph.runs:
            el = run._r.find(qn("w:rPr"))
            if el is not None:
                return deepcopy(el)
        return None

    @staticmethod
    def _buang_semua_run(paragraph) -> None:
        p = paragraph._p
        for r in p.findall(qn("w:r")):
            p.remove(r)

    def _buat_run(self, teks: str, rPr_asal, *, bold=False, strikethrough=False) -> OxmlElement:
        r   = OxmlElement("w:r")
        rPr = deepcopy(rPr_asal) if rPr_asal is not None else OxmlElement("w:rPr")

        for el in rPr.findall(qn("w:strike")):
            rPr.remove(el)
        self._buang_bold(rPr)

        if strikethrough:
            s = OxmlElement("w:strike")
            s.set(qn("w:val"), "true")
            rPr.append(s)
        if bold:
            self._tambah_bold(rPr)

        r.append(rPr)

        pecahan = teks.split("\t")
        for i, sub in enumerate(pecahan):
            if sub:
                t = OxmlElement("w:t")
                t.text = sub
                if sub[0] == " " or sub[-1] == " ":
                    t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
                r.append(t)
            if i < len(pecahan) - 1:
                r.append(OxmlElement("w:tab"))
        return r

    def _ganti_para(self, paragraph, ph_map: dict) -> None:
        teks_penuh = "".join(r.text for r in paragraph.runs)
        if not any(ph in teks_penuh for ph in ph_map):
            return

        berpecah = any(
            ph in teks_penuh and not any(ph in r.text for r in paragraph.runs)
            for ph in ph_map if ph in teks_penuh
        )

        if not berpecah:
            for run in paragraph.runs:
                for ph, nilai in ph_map.items():
                    if ph in run.text:
                        run.text = run.text.replace(ph, nilai)
                        run.bold = True
            return

        rPr_asal = self._dapatkan_rPr(paragraph)
        pattern  = "(" + "|".join(re.escape(k) for k in ph_map) + ")"
        bahagian = re.split(pattern, teks_penuh)

        if not any(b in ph_map for b in bahagian):
            return

        self._buang_semua_run(paragraph)
        for b in bahagian:
            if not b:
                continue
            is_ph = b in ph_map
            teks  = ph_map[b] if is_ph else b
            if teks:
                paragraph._p.append(self._buat_run(teks, rPr_asal, bold=is_ph))

    def _pisah_faedah_dan_ekor(self, selepas: str) -> tuple[list[str], str]:
        token_mentah  = selepas.split(" / ")
        items_faedah: list[str] = []
        ekor = ""

        for i, token in enumerate(token_mentah):
            token_bersih = token.strip()
            faedah_sepadan = next(
                (f for f in self.senarai_faedah if token_bersih.startswith(f)), None,
            )
            if faedah_sepadan is not None:
                items_faedah.append(faedah_sepadan)
                sisa = token_bersih[len(faedah_sepadan):]
                if sisa:
                    baki_tokens = token_mentah[i + 1:]
                    ekor = sisa + (" / " + " / ".join(baki_tokens) if baki_tokens else "")
                    break
            else:
                ekor = " / ".join(token_mentah[i:])
                break

        return items_faedah, ekor

    def _tulis_sebelum(self, p, sebelum: str, ph_map: dict, rPr_asal) -> None:
        nilai_list = [v for v in ph_map.values() if v]
        if nilai_list:
            patt = "(" + "|".join(re.escape(v) for v in nilai_list) + ")"
            for seg in re.split(patt, sebelum):
                if seg:
                    p.append(self._buat_run(seg, rPr_asal, bold=(seg in nilai_list)))
        else:
            p.append(self._buat_run(sebelum, rPr_asal))

    def _strikethrough_para(self, paragraph, pilihan: list[str], ph_map: dict) -> bool:
        teks = paragraph.text

        if sum(1 for f in self.senarai_faedah if f in teks) < 2:
            return False

        bahagian = re.split(r"(sebagai\s*)", teks, maxsplit=1)
        if len(bahagian) < 3:
            return False

        sebelum = bahagian[0] + bahagian[1]
        selepas = bahagian[2]

        for ph, nilai in ph_map.items():
            sebelum = sebelum.replace(ph, nilai)

        items_faedah, ekor = self._pisah_faedah_dan_ekor(selepas)

        rPr_asal = self._dapatkan_rPr(paragraph)
        self._buang_semua_run(paragraph)
        p = paragraph._p

        self._tulis_sebelum(p, sebelum, ph_map, rPr_asal)

        for i, item in enumerate(items_faedah):
            dipilih = item in pilihan
            p.append(self._buat_run(item, rPr_asal, bold=dipilih, strikethrough=not dipilih))
            if i < len(items_faedah) - 1:
                p.append(self._buat_run(" / ", rPr_asal))

        if ekor:
            p.append(self._buat_run(ekor, rPr_asal, bold=False, strikethrough=False))

        return True

    def _proses_para(self, para, jenis_faedah: list[str], ph_map: dict) -> None:
        teks = para.text
        if any(f in teks for f in self.senarai_faedah) and " / " in teks:
            self._strikethrough_para(para, jenis_faedah, ph_map)
        else:
            self._ganti_para(para, ph_map)

    def proses(self, doc: Document, ph_map: dict, jenis_faedah: list[str]) -> None:
        for para in doc.paragraphs:
            self._proses_para(para, jenis_faedah, ph_map)

        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    for para in cell.paragraphs:
                        self._proses_para(para, jenis_faedah, ph_map)


BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def jana_surat_bytes(data: dict, kes: KonfigKes) -> tuple[bytes, str]:
    """Jana surat dan pulangkan (bytes, nama_fail)."""
    template = os.path.join(BASE_DIR, kes.nama_template)
    if not os.path.exists(template):
        raise FileNotFoundError(
            f"Template tidak dijumpai: '{template}'\n"
            f"Pastikan fail template berada dalam folder yang sama dengan app.py."
        )

    doc          = Document(template)
    jumlah_str   = data["jumlah"]
    jumlah_angka = format_jumlah_angka(jumlah_str)
    teks_penuh   = wang_ke_teks(jumlah_str)
    jumlah_teks  = teks_penuh.replace("Ringgit Malaysia: ", "", 1)

    faedah1 = data["jenis_faedah"]
    faedah2 = data.get("jenis_faedah2", "").strip()
    pilihan_faedah = [f for f in (faedah1, faedah2) if f]
    faedah_display = " dan ".join(pilihan_faedah)

    ph_map = kes.bina_ph_map(data, jumlah_angka, jumlah_teks, faedah_display)
    PemprosesDoc(SENARAI_FAEDAH).proses(doc, ph_map, pilihan_faedah)

    cap_masa  = datetime.now().strftime("%Y%m%d_%H%M%S")
    nama_fail = f"Surat_{kes.nama_kes}_{data['nama_waris'].replace(' ', '_')}_{cap_masa}.docx"

    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf.read(), nama_fail


# =============================================================================
# 5. ROUTES
# =============================================================================

@app.route("/")
def index():
    return render_template("index.html", semua_kes=SEMUA_KES)


@app.route("/borang/<nama_kes>")
def borang(nama_kes: str):
    kes = SEMUA_KES.get(nama_kes.upper())
    if not kes:
        return "Kes tidak dijumpai.", 404

    now = datetime.now()
    tarikh_default = f"{now.day:02d} {BULAN_MS[now.month]} {now.year}"

    return render_template(
        "borang.html",
        kes=kes,
        senarai_faedah=SENARAI_FAEDAH,
        tarikh_default=tarikh_default,
    )


@app.route("/pratonton_wang", methods=["POST"])
def pratonton_wang():
    jumlah = request.json.get("jumlah", "")
    teks   = wang_ke_teks(jumlah)
    return jsonify({"teks": teks})


@app.route("/jana/<nama_kes>", methods=["POST"])
def jana(nama_kes: str):
    kes = SEMUA_KES.get(nama_kes.upper())
    if not kes:
        return jsonify({"ralat": "Kes tidak dijumpai."}), 404

    data = {m.kunci: request.form.get(m.kunci, "").strip() for m in kes.senarai_medan}

    # Validasi medan wajib
    for medan in kes.senarai_medan:
        if medan.wajib and not data[medan.kunci]:
            return jsonify({"ralat": f"Sila isi medan: {medan.label}"}), 400

    # Validasi jumlah
    try:
        float(data["jumlah"].replace(",", ""))
    except ValueError:
        return jsonify({"ralat": "Jumlah wang tidak sah. Contoh: 197.19"}), 400

    try:
        fail_bytes, nama_fail = jana_surat_bytes(data, kes)
    except FileNotFoundError as e:
        return jsonify({"ralat": str(e)}), 500
    except Exception as e:
        return jsonify({"ralat": f"Ralat semasa menjana surat: {e}"}), 500

    return send_file(
        io.BytesIO(fail_bytes),
        as_attachment=True,
        download_name=nama_fail,
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    )


if __name__ == "__main__":
    app.run(debug=True)
