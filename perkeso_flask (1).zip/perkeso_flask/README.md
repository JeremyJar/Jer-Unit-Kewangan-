# Jana Surat PERKESO — Web Flask

Versi web daripada aplikasi desktop PyQt5 asal.

## Keperluan

- Python 3.9+
- Flask
- python-docx

## Pemasangan

```bash
pip install -r requirements.txt
```

## Persediaan Template

Letakkan fail template Word dalam **folder yang sama** dengan `app.py`:

```
perkeso_flask/
├── app.py
├── requirements.txt
├── Template OB.docx    ← ⚠ wajib ada
├── Template OT.docx    ← ⚠ wajib ada
└── templates/
    ├── base.html
    ├── index.html
    └── borang.html
```

## Cara Jalankan

```bash
python app.py
```

Kemudian buka pelayar di: **http://localhost:5000**

## Ciri-ciri

- ✅ Borang OB (Orang Berinsurans) — jana surat harta pusaka
- ✅ Borang OT (Orang Tanggungan) — jana surat OT meninggal dunia
- ✅ Pratonton jumlah wang dalam teks Bahasa Malaysia
- ✅ Muat turun terus fail `.docx` dari pelayar
- ✅ Validasi medan wajib
- ✅ Strikethrough faedah yang tidak dipilih (sama seperti versi PyQt5)

## Pengeluaran (Production)

```bash
pip install gunicorn
gunicorn app:app -w 4 -b 0.0.0.0:5000
```
